﻿using System;

namespace MySecondProjectOutput
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hey!\n");
            Console.WriteLine("Hello!");

            //This is a comment

            /*This is a multi line comment
             * i 
             * hope it is 
             * useful
             */

            Console.WriteLine("\tLourenco"); //makes a tab b4 the name
            Console.WriteLine("Lo\burenco"); //It Removes the previous char
            Console.WriteLine("Lou\nrenco"); //It makes a new line

            Console.ReadKey();//It will prevent the console  from closing after executing the program
        }
    }
}
