﻿using System;

namespace Constants
{

    class Program
    {
        static void Main(string[] args)
        {
            /*Constants = immutable values wich are known at compile time
             * and do not change for the life of the program*/

            const double pi = 3.1416;

            pi = 32; //Error: I can't modify pi because it's a constant!

            Console.WriteLine(pi);

            Console.ReadKey();
        }
    }

}