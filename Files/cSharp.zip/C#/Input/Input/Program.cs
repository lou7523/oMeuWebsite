﻿using System;

namespace Input
{

    class Program
    {

        static void Main(String[] args)
        {
            Console.WriteLine("What's your name?");
            string name = Console.ReadLine();

            Console.WriteLine("What's your age?");
            int age = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Age: " + age + " years old");

            Console.ReadKey();
        }
    }
}