﻿using System;

namespace TypeCasting
{
    class Program
    {
        static void Main(String[] args)
        {
            /*Type Casting = Converting a value to a diffrent data type
             * It is useful when we accept user input (ex. string) and 
             * we want to convert it to a diffrent data type (ex. int)
             */


            //double to an int
            double a = 3.14;
            int b = Convert.ToInt32(a);


            //int to a double
            int c = 123;
            double d = Convert.ToDouble(c);


            //int to a string
            int e = 321;
            String f = Convert.ToString(e);

            //String to a char
            String g = "a";
            char h = Convert.ToChar(g);

            //String to a boolean
            String i = "false";
            Boolean j = Convert.ToBoolean(i);

            Console.Write(b + " is an ");
            Console.WriteLine(b.GetType());//Writes b and GetType is to show what type of data b is.
            Console.Write(d + " is a ");
            Console.WriteLine(d.GetType());
            Console.Write(f + " is a ");
            Console.WriteLine(f.GetType());
            Console.Write(h + " is a ");
            Console.WriteLine(h.GetType());
            Console.Write(i + " is a ");
            Console.WriteLine(j.GetType());


            Console.ReadKey();
        }
    }
}