﻿using System;

namespace Variables
{
    class Variables
    {
        static void Main(string[] args)
        {
            int x;//declaration of variable x
            x = 123; //initialization of variable x

            int y = 321;//declaration + initialization

            int z = x + y; //sum of x and y

            int age = 16;//only integer numbers
            double height = 175;//double saves decimal numbers
            bool alive = false; //its only true or false
            char symbol = '@';//single character, uses single quotes
            String name = "Lourenco";//series of chars

            Console.WriteLine("Hello my name is " + name + " and ");
            Console.WriteLine("I am " + age + " years old");
            Console.WriteLine("I have " + height + " cm");
            Console.WriteLine("Are you alive?\n:" + alive);
            Console.WriteLine("Your symbol is " + symbol);

            String userName = symbol + name;

            Console.WriteLine("Your username is: " + userName);

            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine(z);


            Console.ReadKey();
        }

    }

}