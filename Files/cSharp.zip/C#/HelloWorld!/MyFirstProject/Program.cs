﻿using System;

namespace MyFirstProgram

{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I love C#!");
            Console.WriteLine("I hope to learn more!");
            Console.Beep();
        }
    }

}